# Quick Start Guide

## What You Have

You now have a complete WordPress theme called **"Learning Opportunities"** that replicates the design from your screenshot.

## Files Included

- `learning-opportunities-theme.zip` - Ready-to-install WordPress theme
- `learning-opportunities-theme/` - Theme source files (for reference or editing)

## Installation (3 Simple Steps)

### 1. Upload Theme to WordPress
- Log in to your WordPress admin panel
- Go to **Appearance → Themes → Add New**
- Click **Upload Theme**
- Choose `learning-opportunities-theme.zip`
- Click **Install Now** then **Activate**

### 2. Set Up Permalinks
- Go to **Settings → Permalinks**
- Select **Post name**
- Click **Save Changes**

### 3. Add Your Content
- Go to **Courses → Universities** - Add universities
- Go to **Courses → Learning Pathways** - Add pathways
- Go to **Courses → Languages** - Add languages (EN, FR, DE, etc.)
- Go to **Courses → Add New** - Add courses with details

## Features Included

✅ Custom "Courses" post type
✅ Advanced filtering sidebar (University, Area, Pathway, ECTS, etc.)
✅ AJAX live search (no page reload)
✅ Course cards with status badges (Open/Closed)
✅ ECTS credits display
✅ Delivery mode indicators (Online, Hybrid, Onsite)
✅ Language indicators
✅ Start date and registration deadline
✅ University course catalogues section
✅ Responsive design (mobile-friendly)
✅ Blue color scheme matching your design

## Where to Find Things

- **Courses Archive**: `/courses/` or **Learning Opportunities** menu item
- **Single Course**: Click any course card
- **Admin Panel**: **Courses** menu in WordPress admin

## Customization

### Change Colors
Edit `wp-content/themes/learning-opportunities-theme/assets/css/main.css`
Look for CSS variables at the top:
- `--primary-blue: #3d5a96;`
- `--dark-blue: #2c4270;`

### Add University Logos
Edit `footer.php` and replace the `.footer-logo` divs with actual images.

### Modify Filters
Edit `archive-course.php` to add/remove filter options.

## Need More Help?

- Check `INSTALLATION.md` for detailed setup instructions
- Check `README.md` for full documentation
- All files are well-commented for easy customization

## Important Notes

- This theme requires WordPress 5.0+ and PHP 7.4+
- Make sure to add content (universities, courses) to see the full design
- The filtering works via AJAX for smooth user experience
- All course data is stored in WordPress custom post types

## Theme Structure

```
learning-opportunities-theme/
├── assets/
│   ├── css/main.css          (All styling)
│   └── js/main.js            (AJAX filtering)
├── template-parts/
│   └── content-course.php    (Course card template)
├── archive-course.php        (Main courses page)
├── single-course.php         (Single course page)
├── header.php                (Site header)
├── footer.php                (Site footer)
├── functions.php             (Theme functionality)
└── style.css                 (Theme info)
```

## Ready to Go!

Your theme is ready to import into WordPress. Just upload the ZIP file and start adding courses!

---

**Theme Name**: Learning Opportunities
**Version**: 1.0.0
**License**: GPL v2 or later
