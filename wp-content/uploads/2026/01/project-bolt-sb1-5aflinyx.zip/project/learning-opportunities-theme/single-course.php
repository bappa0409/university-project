<?php get_header(); ?>

<?php while (have_posts()) : the_post(); ?>
    <div class="hero-section">
        <div class="container">
            <h1 class="page-title"><?php the_title(); ?></h1>
            <div class="breadcrumbs">
                <a href="<?php echo home_url(); ?>"><span class="home-icon">🏠</span></a>
                <span class="separator">/</span>
                <a href="<?php echo get_post_type_archive_link('course'); ?>"><?php _e('Learning opportunities', 'learning-opportunities'); ?></a>
                <span class="separator">/</span>
                <span><?php the_title(); ?></span>
            </div>
        </div>
    </div>

    <div class="single-course-wrapper">
        <div class="container">
            <div class="course-content">
                <div class="course-main">
                    <?php the_content(); ?>
                </div>

                <aside class="course-sidebar">
                    <div class="course-meta-box">
                        <?php
                        $ects = get_post_meta(get_the_ID(), '_course_ects', true);
                        $status = get_post_meta(get_the_ID(), '_course_status', true);
                        $start_date = get_post_meta(get_the_ID(), '_course_start_date', true);
                        $registration_date = get_post_meta(get_the_ID(), '_course_registration_date', true);
                        $delivery_mode = get_post_meta(get_the_ID(), '_course_delivery_mode', true);
                        ?>

                        <?php if ($status) : ?>
                            <div class="status-badge <?php echo $status === 'open' ? 'status-open' : 'status-closed'; ?>">
                                <?php echo strtoupper($status); ?>
                            </div>
                        <?php endif; ?>

                        <?php if ($ects) : ?>
                            <div class="meta-item">
                                <strong><?php _e('ECTS Credits:', 'learning-opportunities'); ?></strong>
                                <span><?php echo $ects; ?> ECTS</span>
                            </div>
                        <?php endif; ?>

                        <?php
                        $universities = get_the_terms(get_the_ID(), 'university');
                        if ($universities && !is_wp_error($universities)) :
                            ?>
                            <div class="meta-item">
                                <strong><?php _e('University:', 'learning-opportunities'); ?></strong>
                                <span><?php echo $universities[0]->name; ?></span>
                            </div>
                        <?php endif; ?>

                        <?php if ($delivery_mode) : ?>
                            <div class="meta-item">
                                <strong><?php _e('Delivery Mode:', 'learning-opportunities'); ?></strong>
                                <span><?php echo ucfirst($delivery_mode); ?></span>
                            </div>
                        <?php endif; ?>

                        <?php if ($start_date) : ?>
                            <div class="meta-item">
                                <strong><?php _e('Start Date:', 'learning-opportunities'); ?></strong>
                                <span><?php echo date('d.m.Y', strtotime($start_date)); ?></span>
                            </div>
                        <?php endif; ?>

                        <?php if ($registration_date) : ?>
                            <div class="meta-item">
                                <strong><?php _e('Registration Deadline:', 'learning-opportunities'); ?></strong>
                                <span><?php echo date('d.m.Y', strtotime($registration_date)); ?></span>
                            </div>
                        <?php endif; ?>

                        <?php
                        $pathways = get_the_terms(get_the_ID(), 'learning_pathway');
                        if ($pathways && !is_wp_error($pathways)) :
                            ?>
                            <div class="meta-item">
                                <strong><?php _e('Learning Pathways:', 'learning-opportunities'); ?></strong>
                                <div class="pathway-tags">
                                    <?php foreach ($pathways as $pathway) : ?>
                                        <span class="pathway-tag"><?php echo $pathway->name; ?></span>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php
                        $languages = get_the_terms(get_the_ID(), 'course_language');
                        if ($languages && !is_wp_error($languages)) :
                            ?>
                            <div class="meta-item">
                                <strong><?php _e('Languages:', 'learning-opportunities'); ?></strong>
                                <span><?php echo implode(', ', wp_list_pluck($languages, 'name')); ?></span>
                            </div>
                        <?php endif; ?>
                    </div>
                </aside>
            </div>
        </div>
    </div>
<?php endwhile; ?>

<?php get_footer(); ?>
