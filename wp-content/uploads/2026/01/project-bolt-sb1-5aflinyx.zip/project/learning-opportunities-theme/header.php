<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-header">
    <div class="container">
        <nav class="main-navigation">
            <div class="nav-left">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'menu_class' => 'primary-menu',
                    'container' => false,
                    'fallback_cb' => function() {
                        echo '<ul class="primary-menu">';
                        echo '<li><a href="' . home_url() . '">Home</a></li>';
                        echo '<li><a href="#">Wizard</a></li>';
                        echo '<li><a href="' . get_post_type_archive_link('course') . '">Learning opportunities</a></li>';
                        echo '</ul>';
                    }
                ));
                ?>
            </div>
            <div class="nav-right">
                <a href="#" class="login-link">Log in</a>
                <div class="language-selector">
                    <button class="lang-button">
                        <span class="flag-icon">🇪🇺</span> EU+
                    </button>
                </div>
            </div>
        </nav>
    </div>
</header>
