<?php

function learning_opportunities_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));

    register_nav_menus(array(
        'primary' => __('Primary Menu', 'learning-opportunities'),
        'footer' => __('Footer Menu', 'learning-opportunities'),
    ));
}
add_action('after_setup_theme', 'learning_opportunities_setup');

function learning_opportunities_enqueue_scripts() {
    wp_enqueue_style('learning-opportunities-style', get_stylesheet_uri());
    wp_enqueue_style('learning-opportunities-main', get_template_directory_uri() . '/assets/css/main.css', array(), '1.0.0');

    wp_enqueue_script('learning-opportunities-main', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), '1.0.0', true);

    wp_localize_script('learning-opportunities-main', 'loAjax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('lo_filter_nonce')
    ));
}
add_action('wp_enqueue_scripts', 'learning_opportunities_enqueue_scripts');

function learning_opportunities_register_post_types() {
    register_post_type('course', array(
        'labels' => array(
            'name' => __('Courses', 'learning-opportunities'),
            'singular_name' => __('Course', 'learning-opportunities'),
            'add_new' => __('Add New Course', 'learning-opportunities'),
            'add_new_item' => __('Add New Course', 'learning-opportunities'),
            'edit_item' => __('Edit Course', 'learning-opportunities'),
            'new_item' => __('New Course', 'learning-opportunities'),
            'view_item' => __('View Course', 'learning-opportunities'),
            'search_items' => __('Search Courses', 'learning-opportunities'),
            'not_found' => __('No courses found', 'learning-opportunities'),
        ),
        'public' => true,
        'has_archive' => true,
        'rewrite' => array('slug' => 'courses'),
        'show_in_rest' => true,
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-welcome-learn-more',
    ));
}
add_action('init', 'learning_opportunities_register_post_types');

function learning_opportunities_register_taxonomies() {
    register_taxonomy('university', 'course', array(
        'labels' => array(
            'name' => __('Universities', 'learning-opportunities'),
            'singular_name' => __('University', 'learning-opportunities'),
        ),
        'hierarchical' => true,
        'show_in_rest' => true,
        'rewrite' => array('slug' => 'university'),
    ));

    register_taxonomy('area_of_interest', 'course', array(
        'labels' => array(
            'name' => __('Areas of Interest', 'learning-opportunities'),
            'singular_name' => __('Area of Interest', 'learning-opportunities'),
        ),
        'hierarchical' => true,
        'show_in_rest' => true,
        'rewrite' => array('slug' => 'area'),
    ));

    register_taxonomy('flagship', 'course', array(
        'labels' => array(
            'name' => __('Flagships', 'learning-opportunities'),
            'singular_name' => __('Flagship', 'learning-opportunities'),
        ),
        'hierarchical' => true,
        'show_in_rest' => true,
        'rewrite' => array('slug' => 'flagship'),
    ));

    register_taxonomy('learning_pathway', 'course', array(
        'labels' => array(
            'name' => __('Learning Pathways', 'learning-opportunities'),
            'singular_name' => __('Learning Pathway', 'learning-opportunities'),
        ),
        'hierarchical' => true,
        'show_in_rest' => true,
        'rewrite' => array('slug' => 'pathway'),
    ));

    register_taxonomy('course_format', 'course', array(
        'labels' => array(
            'name' => __('Course Formats', 'learning-opportunities'),
            'singular_name' => __('Course Format', 'learning-opportunities'),
        ),
        'hierarchical' => true,
        'show_in_rest' => true,
        'rewrite' => array('slug' => 'format'),
    ));

    register_taxonomy('target_group', 'course', array(
        'labels' => array(
            'name' => __('Target Groups', 'learning-opportunities'),
            'singular_name' => __('Target Group', 'learning-opportunities'),
        ),
        'hierarchical' => true,
        'show_in_rest' => true,
        'rewrite' => array('slug' => 'target-group'),
    ));

    register_taxonomy('course_language', 'course', array(
        'labels' => array(
            'name' => __('Languages', 'learning-opportunities'),
            'singular_name' => __('Language', 'learning-opportunities'),
        ),
        'hierarchical' => true,
        'show_in_rest' => true,
        'rewrite' => array('slug' => 'language'),
    ));
}
add_action('init', 'learning_opportunities_register_taxonomies');

function learning_opportunities_add_meta_boxes() {
    add_meta_box(
        'course_details',
        __('Course Details', 'learning-opportunities'),
        'learning_opportunities_course_details_callback',
        'course',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'learning_opportunities_add_meta_boxes');

function learning_opportunities_course_details_callback($post) {
    wp_nonce_field('learning_opportunities_save_course_details', 'learning_opportunities_course_details_nonce');

    $ects = get_post_meta($post->ID, '_course_ects', true);
    $status = get_post_meta($post->ID, '_course_status', true);
    $start_date = get_post_meta($post->ID, '_course_start_date', true);
    $registration_date = get_post_meta($post->ID, '_course_registration_date', true);
    $delivery_mode = get_post_meta($post->ID, '_course_delivery_mode', true);
    ?>
    <p>
        <label for="course_ects"><?php _e('ECTS Credits:', 'learning-opportunities'); ?></label>
        <input type="number" id="course_ects" name="course_ects" value="<?php echo esc_attr($ects); ?>" min="0" max="30" />
    </p>
    <p>
        <label for="course_status"><?php _e('Status:', 'learning-opportunities'); ?></label>
        <select id="course_status" name="course_status">
            <option value="open" <?php selected($status, 'open'); ?>><?php _e('Open', 'learning-opportunities'); ?></option>
            <option value="closed" <?php selected($status, 'closed'); ?>><?php _e('Closed', 'learning-opportunities'); ?></option>
        </select>
    </p>
    <p>
        <label for="course_start_date"><?php _e('Start Date:', 'learning-opportunities'); ?></label>
        <input type="date" id="course_start_date" name="course_start_date" value="<?php echo esc_attr($start_date); ?>" />
    </p>
    <p>
        <label for="course_registration_date"><?php _e('Registration Deadline:', 'learning-opportunities'); ?></label>
        <input type="date" id="course_registration_date" name="course_registration_date" value="<?php echo esc_attr($registration_date); ?>" />
    </p>
    <p>
        <label for="course_delivery_mode"><?php _e('Delivery Mode:', 'learning-opportunities'); ?></label>
        <select id="course_delivery_mode" name="course_delivery_mode">
            <option value="online" <?php selected($delivery_mode, 'online'); ?>><?php _e('Online', 'learning-opportunities'); ?></option>
            <option value="hybrid" <?php selected($delivery_mode, 'hybrid'); ?>><?php _e('Hybrid', 'learning-opportunities'); ?></option>
            <option value="onsite" <?php selected($delivery_mode, 'onsite'); ?>><?php _e('Onsite', 'learning-opportunities'); ?></option>
        </select>
    </p>
    <?php
}

function learning_opportunities_save_course_details($post_id) {
    if (!isset($_POST['learning_opportunities_course_details_nonce'])) {
        return;
    }
    if (!wp_verify_nonce($_POST['learning_opportunities_course_details_nonce'], 'learning_opportunities_save_course_details')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    if (isset($_POST['course_ects'])) {
        update_post_meta($post_id, '_course_ects', sanitize_text_field($_POST['course_ects']));
    }
    if (isset($_POST['course_status'])) {
        update_post_meta($post_id, '_course_status', sanitize_text_field($_POST['course_status']));
    }
    if (isset($_POST['course_start_date'])) {
        update_post_meta($post_id, '_course_start_date', sanitize_text_field($_POST['course_start_date']));
    }
    if (isset($_POST['course_registration_date'])) {
        update_post_meta($post_id, '_course_registration_date', sanitize_text_field($_POST['course_registration_date']));
    }
    if (isset($_POST['course_delivery_mode'])) {
        update_post_meta($post_id, '_course_delivery_mode', sanitize_text_field($_POST['course_delivery_mode']));
    }
}
add_action('save_post', 'learning_opportunities_save_course_details');

function learning_opportunities_filter_courses() {
    check_ajax_referer('lo_filter_nonce', 'nonce');

    $args = array(
        'post_type' => 'course',
        'posts_per_page' => 12,
        'paged' => isset($_POST['page']) ? intval($_POST['page']) : 1,
    );

    $meta_query = array('relation' => 'AND');
    $tax_query = array('relation' => 'AND');

    if (!empty($_POST['search'])) {
        $args['s'] = sanitize_text_field($_POST['search']);
    }

    if (!empty($_POST['university'])) {
        $tax_query[] = array(
            'taxonomy' => 'university',
            'field' => 'term_id',
            'terms' => intval($_POST['university']),
        );
    }

    if (!empty($_POST['area_of_interest'])) {
        $tax_query[] = array(
            'taxonomy' => 'area_of_interest',
            'field' => 'term_id',
            'terms' => intval($_POST['area_of_interest']),
        );
    }

    if (!empty($_POST['flagship'])) {
        $tax_query[] = array(
            'taxonomy' => 'flagship',
            'field' => 'term_id',
            'terms' => intval($_POST['flagship']),
        );
    }

    if (!empty($_POST['learning_pathway'])) {
        $tax_query[] = array(
            'taxonomy' => 'learning_pathway',
            'field' => 'term_id',
            'terms' => intval($_POST['learning_pathway']),
        );
    }

    if (!empty($_POST['course_format'])) {
        $tax_query[] = array(
            'taxonomy' => 'course_format',
            'field' => 'term_id',
            'terms' => intval($_POST['course_format']),
        );
    }

    if (!empty($_POST['target_group'])) {
        $tax_query[] = array(
            'taxonomy' => 'target_group',
            'field' => 'term_id',
            'terms' => intval($_POST['target_group']),
        );
    }

    if (!empty($_POST['language'])) {
        $tax_query[] = array(
            'taxonomy' => 'course_language',
            'field' => 'term_id',
            'terms' => intval($_POST['language']),
        );
    }

    if (!empty($_POST['ects_min']) || !empty($_POST['ects_max'])) {
        $meta_query[] = array(
            'key' => '_course_ects',
            'value' => array(
                !empty($_POST['ects_min']) ? intval($_POST['ects_min']) : 0,
                !empty($_POST['ects_max']) ? intval($_POST['ects_max']) : 30
            ),
            'type' => 'NUMERIC',
            'compare' => 'BETWEEN',
        );
    }

    if (!empty($_POST['date_from'])) {
        $meta_query[] = array(
            'key' => '_course_start_date',
            'value' => sanitize_text_field($_POST['date_from']),
            'compare' => '>=',
            'type' => 'DATE',
        );
    }

    if (!empty($_POST['date_to'])) {
        $meta_query[] = array(
            'key' => '_course_start_date',
            'value' => sanitize_text_field($_POST['date_to']),
            'compare' => '<=',
            'type' => 'DATE',
        );
    }

    if (count($meta_query) > 1) {
        $args['meta_query'] = $meta_query;
    }

    if (count($tax_query) > 1) {
        $args['tax_query'] = $tax_query;
    }

    $query = new WP_Query($args);

    ob_start();

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            get_template_part('template-parts/content', 'course');
        }
    } else {
        echo '<p class="no-results">' . __('No courses found matching your criteria.', 'learning-opportunities') . '</p>';
    }

    $html = ob_get_clean();

    wp_send_json_success(array(
        'html' => $html,
        'found_posts' => $query->found_posts,
        'max_pages' => $query->max_num_pages,
    ));
}
add_action('wp_ajax_filter_courses', 'learning_opportunities_filter_courses');
add_action('wp_ajax_nopriv_filter_courses', 'learning_opportunities_filter_courses');
