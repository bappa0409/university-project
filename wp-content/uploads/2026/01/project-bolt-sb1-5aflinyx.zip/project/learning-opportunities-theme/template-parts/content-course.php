<?php
$ects = get_post_meta(get_the_ID(), '_course_ects', true);
$status = get_post_meta(get_the_ID(), '_course_status', true);
$start_date = get_post_meta(get_the_ID(), '_course_start_date', true);
$registration_date = get_post_meta(get_the_ID(), '_course_registration_date', true);
$delivery_mode = get_post_meta(get_the_ID(), '_course_delivery_mode', true);

$universities = get_the_terms(get_the_ID(), 'university');
$pathways = get_the_terms(get_the_ID(), 'learning_pathway');
$languages = get_the_terms(get_the_ID(), 'course_language');

$colors = array('#9dd9e8', '#f8d347', '#f5a623');
$color = $colors[array_rand($colors)];
?>

<article class="course-card">
    <div class="course-card-header">
        <div class="university-badge">
            <span class="university-icon">🏛️</span>
            <span class="status-badge <?php echo $status === 'open' ? 'status-open' : 'status-closed'; ?>">
                <?php echo strtoupper($status); ?>
            </span>
            <?php if ($ects) : ?>
                <span class="ects-badge"><?php echo $ects; ?> ECTS</span>
            <?php endif; ?>
        </div>
        <?php if ($universities && !is_wp_error($universities)) : ?>
            <div class="university-name"><?php echo $universities[0]->name; ?></div>
        <?php endif; ?>
    </div>

    <?php if ($pathways && !is_wp_error($pathways)) : ?>
        <div class="course-pathways">
            <?php foreach ($pathways as $pathway) : ?>
                <span class="pathway-badge"><?php echo $pathway->name; ?></span>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="course-meta-info">
        <?php if ($delivery_mode) : ?>
            <span class="meta-badge">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                    <line x1="8" y1="21" x2="16" y2="21"></line>
                    <line x1="12" y1="17" x2="12" y2="21"></line>
                </svg>
                <?php echo ucfirst($delivery_mode); ?>
            </span>
        <?php endif; ?>

        <?php if ($languages && !is_wp_error($languages)) : ?>
            <?php foreach ($languages as $language) : ?>
                <span class="meta-badge">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="2" y1="12" x2="22" y2="12"></line>
                        <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                    </svg>
                    <?php echo strtoupper($language->name); ?>
                </span>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <h3 class="course-title">
        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
    </h3>

    <div class="course-dates">
        <?php if ($start_date) : ?>
            <div class="date-item">
                <strong><?php _e('Starts', 'learning-opportunities'); ?>:</strong>
                <?php echo date('d.m.Y', strtotime($start_date)); ?>
            </div>
        <?php endif; ?>
        <?php if ($registration_date) : ?>
            <div class="date-item">
                <strong><?php _e('Registration up to', 'learning-opportunities'); ?>:</strong>
                <?php echo date('d.m.Y', strtotime($registration_date)); ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="course-indicator" style="background-color: <?php echo $color; ?>"></div>
</article>
