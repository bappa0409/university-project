-- Sample Data for Learning Opportunities Theme
-- Import this file after activating the theme to get started with sample content

-- Note: This is a reference file. You should add sample data through the WordPress admin interface
-- or use a plugin like WP All Import for bulk importing.

-- Sample Universities (Add via WordPress Admin: Courses > Universities)
-- - Sorbonne University
-- - Heidelberg University
-- - University of Warsaw
-- - Charles University
-- - Paris Panthéon-Assas University
-- - University of Copenhagen
-- - University of Geneva
-- - University of Milan

-- Sample Areas of Interest
-- - Science
-- - Humanities
-- - Social Sciences
-- - Engineering
-- - Medicine

-- Sample Flagships
-- - Research
-- - Innovation
-- - Sustainability

-- Sample Learning Pathways
-- - Multilingualism
-- - European Citizenship
-- - Digital Skills

-- Sample Course Formats
-- - Online
-- - Hybrid
-- - Onsite

-- Sample Target Groups
-- - Bachelor Students
-- - Master Students
-- - PhD Candidates

-- Sample Languages
-- - EN (English)
-- - FR (French)
-- - DE (German)
-- - PL (Polish)

-- Sample Courses (Add via WordPress Admin: Courses > Add New)
/*
1. Open Science MOOC
   - University: Sorbonne University
   - ECTS: 15
   - Status: Open
   - Delivery Mode: Online
   - Languages: EN, FR
   - Learning Pathway: Multilingualism

2. Open Euraud Translation and Terminology: Translating...
   - University: Heidelberg University
   - ECTS: 15
   - Status: Closed
   - Delivery Mode: Hybrid
   - Languages: EN, DE

3. Fundamental Molecular Biosciences
   - University: Sorbonne University
   - ECTS: 15
   - Status: Closed
   - Delivery Mode: Online
   - Languages: EN

4. Open Science MOOC
   - University: University of Warsaw
   - ECTS: 4
   - Status: Closed
   - Delivery Mode: Hybrid
   - Languages: EN, PL

5. Seminar of French social sciences and humanities
   - University: Sorbonne University
   - ECTS: 4
   - Status: Closed
   - Delivery Mode: Hybrid
   - Languages: FR

6. High-Performance Computing for Computational Science
   - University: Charles University
   - ECTS: 5
   - Status: Closed
   - Delivery Mode: Hybrid
   - Languages: EN

7. Political Science
   - University: University of Milan
   - ECTS: 9
   - Status: Closed
   - Delivery Mode: Hybrid
   - Languages: EN

*/
