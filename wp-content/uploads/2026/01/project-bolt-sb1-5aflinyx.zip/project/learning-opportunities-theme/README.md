# Learning Opportunities WordPress Theme

A professional WordPress theme for displaying learning opportunities, courses, and educational programs with advanced filtering and search capabilities.

## Features

- Custom Post Type: Courses
- Multiple Taxonomies: Universities, Areas of Interest, Flagships, Learning Pathways, Course Formats, Target Groups, Languages
- Advanced Filtering System with AJAX
- Course Details: ECTS credits, Status (Open/Closed), Start Date, Registration Deadline, Delivery Mode
- Responsive Design
- Clean, Modern Interface
- University Course Catalogues Section

## Installation

1. Download the theme folder
2. Compress it to a ZIP file named `learning-opportunities-theme.zip`
3. In WordPress Admin, go to Appearance > Themes > Add New
4. Click "Upload Theme" and select the ZIP file
5. Click "Install Now" and then "Activate"

## Setup

### Required Pages

The theme works best with the following setup:

1. Set up your homepage
2. The courses archive will be automatically available at `/courses/`

### Adding Content

#### 1. Add Universities
- Go to Courses > Universities
- Add your universities as taxonomy terms

#### 2. Add Other Taxonomies
- Areas of Interest: Courses > Areas of Interest
- Flagships: Courses > Flagships
- Learning Pathways: Courses > Learning Pathways
- Course Formats: Courses > Course Formats
- Target Groups: Courses > Target Groups
- Languages: Courses > Languages

#### 3. Add Courses
- Go to Courses > Add New Course
- Fill in the course title and description
- In the Course Details meta box, add:
  - ECTS Credits
  - Status (Open/Closed)
  - Start Date
  - Registration Deadline
  - Delivery Mode
- Select relevant taxonomies (University, Area, etc.)
- Publish the course

### Menus

Set up your menus:
1. Go to Appearance > Menus
2. Create a menu for "Primary Menu" (header navigation)
3. Create a menu for "Footer Menu" (footer navigation)
4. Add items like:
   - Home
   - Wizard (custom link)
   - Learning Opportunities (link to /courses/)

## Customization

### Colors

The theme uses CSS variables defined in `style.css`. You can customize colors by modifying:

- `--primary-blue`: Main theme color
- `--dark-blue`: Darker accent
- `--light-blue`: Light backgrounds
- `--cyan`: Accent color
- `--red`: Status indicators
- `--orange`: Accent color
- `--yellow`: Accent color

### Adding University Logos

To add university logos in the footer:

1. Edit `footer.php`
2. Replace the `.footer-logo` divs with actual logo images
3. Or add logos via a custom field/widget

## Theme Structure

```
learning-opportunities-theme/
├── assets/
│   ├── css/
│   │   └── main.css
│   └── js/
│       └── main.js
├── template-parts/
│   └── content-course.php
├── archive-course.php
├── footer.php
├── functions.php
├── header.php
├── index.php
├── single-course.php
├── style.css
└── README.md
```

## AJAX Filtering

The theme includes real-time AJAX filtering for courses based on:
- Search keywords
- University
- Area of Interest
- Flagship
- Learning Pathway
- Course Format
- Target Group
- Language
- ECTS Credits (range)
- Course Date (from/to)
- Application Date (from/to)

Users can filter courses without page reload for a seamless experience.

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Requirements

- WordPress 5.0 or higher
- PHP 7.4 or higher
- MySQL 5.6 or higher

## Support

For support and questions, please contact the theme developer.

## License

This theme is licensed under the GNU General Public License v2 or later.

## Changelog

### Version 1.0.0
- Initial release
- Custom post types and taxonomies
- Advanced filtering system
- Responsive design
- AJAX course search
