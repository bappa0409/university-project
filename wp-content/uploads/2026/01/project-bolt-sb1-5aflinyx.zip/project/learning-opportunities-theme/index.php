<?php get_header(); ?>

<div class="page-wrapper">
    <?php if (have_posts()) : ?>
        <div class="container">
            <div class="content-grid">
                <?php while (have_posts()) : the_post(); ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        <?php the_excerpt(); ?>
                    </article>
                <?php endwhile; ?>
            </div>
        </div>
    <?php else : ?>
        <div class="container">
            <p><?php _e('No content found.', 'learning-opportunities'); ?></p>
        </div>
    <?php endif; ?>
</div>

<?php get_footer(); ?>
