<?php get_header(); ?>

<div class="hero-section">
    <div class="container">
        <h1 class="page-title"><?php _e('Learning opportunities', 'learning-opportunities'); ?></h1>
        <div class="breadcrumbs">
            <a href="<?php echo home_url(); ?>"><span class="home-icon">🏠</span></a>
            <span class="separator">/</span>
            <span><?php _e('Learning opportunities', 'learning-opportunities'); ?></span>
        </div>
    </div>
</div>

<div class="courses-wrapper">
    <div class="container">
        <div class="courses-layout">
            <aside class="sidebar">
                <div class="filter-box">
                    <h2><?php _e('Search for courses', 'learning-opportunities'); ?></h2>

                    <div class="filter-group">
                        <div class="search-input-wrapper">
                            <input type="text" id="course-search" placeholder="<?php _e('Science', 'learning-opportunities'); ?>" />
                            <button class="clear-search">&times;</button>
                        </div>
                    </div>

                    <div class="filter-group">
                        <label><?php _e('University', 'learning-opportunities'); ?></label>
                        <select id="filter-university">
                            <option value=""><?php _e('All Universities', 'learning-opportunities'); ?></option>
                            <?php
                            $universities = get_terms(array('taxonomy' => 'university', 'hide_empty' => false));
                            foreach ($universities as $university) {
                                echo '<option value="' . $university->term_id . '">' . $university->name . '</option>';
                            }
                            ?>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label><?php _e('Areas of interest', 'learning-opportunities'); ?></label>
                        <select id="filter-area">
                            <option value=""><?php _e('All Areas', 'learning-opportunities'); ?></option>
                            <?php
                            $areas = get_terms(array('taxonomy' => 'area_of_interest', 'hide_empty' => false));
                            foreach ($areas as $area) {
                                echo '<option value="' . $area->term_id . '">' . $area->name . '</option>';
                            }
                            ?>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label><?php _e('Flagship', 'learning-opportunities'); ?></label>
                        <select id="filter-flagship">
                            <option value=""><?php _e('All Flagships', 'learning-opportunities'); ?></option>
                            <?php
                            $flagships = get_terms(array('taxonomy' => 'flagship', 'hide_empty' => false));
                            foreach ($flagships as $flagship) {
                                echo '<option value="' . $flagship->term_id . '">' . $flagship->name . '</option>';
                            }
                            ?>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label><?php _e('Learning pathway', 'learning-opportunities'); ?></label>
                        <select id="filter-pathway">
                            <option value=""><?php _e('All Pathways', 'learning-opportunities'); ?></option>
                            <?php
                            $pathways = get_terms(array('taxonomy' => 'learning_pathway', 'hide_empty' => false));
                            foreach ($pathways as $pathway) {
                                echo '<option value="' . $pathway->term_id . '">' . $pathway->name . '</option>';
                            }
                            ?>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label><?php _e('Course format', 'learning-opportunities'); ?></label>
                        <select id="filter-format">
                            <option value=""><?php _e('All Formats', 'learning-opportunities'); ?></option>
                            <?php
                            $formats = get_terms(array('taxonomy' => 'course_format', 'hide_empty' => false));
                            foreach ($formats as $format) {
                                echo '<option value="' . $format->term_id . '">' . $format->name . '</option>';
                            }
                            ?>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label><?php _e('Target group', 'learning-opportunities'); ?></label>
                        <select id="filter-target">
                            <option value=""><?php _e('All Target Groups', 'learning-opportunities'); ?></option>
                            <?php
                            $targets = get_terms(array('taxonomy' => 'target_group', 'hide_empty' => false));
                            foreach ($targets as $target) {
                                echo '<option value="' . $target->term_id . '">' . $target->name . '</option>';
                            }
                            ?>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label><?php _e('Language', 'learning-opportunities'); ?></label>
                        <select id="filter-language">
                            <option value=""><?php _e('All Languages', 'learning-opportunities'); ?></option>
                            <?php
                            $languages = get_terms(array('taxonomy' => 'course_language', 'hide_empty' => false));
                            foreach ($languages as $language) {
                                echo '<option value="' . $language->term_id . '">' . $language->name . '</option>';
                            }
                            ?>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label><?php _e('Course date', 'learning-opportunities'); ?></label>
                        <input type="date" id="filter-date-from" placeholder="<?php _e('From', 'learning-opportunities'); ?>" />
                        <input type="date" id="filter-date-to" placeholder="<?php _e('To', 'learning-opportunities'); ?>" />
                    </div>

                    <div class="filter-group">
                        <label><?php _e('Application date', 'learning-opportunities'); ?></label>
                        <input type="date" id="filter-app-from" placeholder="<?php _e('From', 'learning-opportunities'); ?>" />
                        <input type="date" id="filter-app-to" placeholder="<?php _e('To', 'learning-opportunities'); ?>" />
                    </div>

                    <div class="filter-group">
                        <label><?php _e('ECTS', 'learning-opportunities'); ?></label>
                        <div class="ects-slider">
                            <input type="range" id="ects-min" min="0" max="30" value="0" />
                            <input type="range" id="ects-max" min="0" max="30" value="30" />
                            <div class="ects-values">
                                <span id="ects-min-value">0</span>
                                <span id="ects-max-value">30</span>
                            </div>
                        </div>
                    </div>

                    <div class="filter-actions">
                        <button class="btn btn-primary" id="search-btn"><?php _e('SEARCH', 'learning-opportunities'); ?></button>
                        <button class="btn btn-secondary" id="clear-btn"><?php _e('CLEAR ALL', 'learning-opportunities'); ?></button>
                    </div>
                </div>
            </aside>

            <main class="main-content">
                <div class="results-header">
                    <h2><?php _e('Results', 'learning-opportunities'); ?></h2>
                    <p class="results-count"><span id="course-count"><?php echo wp_count_posts('course')->publish; ?></span> <?php _e('of', 'learning-opportunities'); ?> <span id="total-count"><?php echo wp_count_posts('course')->publish; ?></span> <?php _e('courses', 'learning-opportunities'); ?></p>
                    <div class="active-filters" id="active-filters"></div>
                </div>

                <div class="courses-grid" id="courses-grid">
                    <?php
                    $courses_query = new WP_Query(array(
                        'post_type' => 'course',
                        'posts_per_page' => 12,
                    ));

                    if ($courses_query->have_posts()) :
                        while ($courses_query->have_posts()) : $courses_query->the_post();
                            get_template_part('template-parts/content', 'course');
                        endwhile;
                    else :
                        echo '<p class="no-results">' . __('No courses found.', 'learning-opportunities') . '</p>';
                    endif;
                    wp_reset_postdata();
                    ?>
                </div>

                <?php if ($courses_query->max_num_pages > 1) : ?>
                    <div class="pagination">
                        <button class="page-prev">&laquo;</button>
                        <span class="page-info">1 <?php _e('of', 'learning-opportunities'); ?> <?php echo $courses_query->max_num_pages; ?></span>
                        <button class="page-next">&raquo;</button>
                    </div>
                <?php endif; ?>
            </main>
        </div>
    </div>
</div>

<div class="universities-section">
    <div class="container">
        <h2><?php _e('University course catalogues', 'learning-opportunities'); ?></h2>
        <p><?php _e('See all available courses for both longer exchanges with Erasmus + and more.', 'learning-opportunities'); ?></p>

        <div class="universities-grid">
            <?php
            $universities = get_terms(array(
                'taxonomy' => 'university',
                'hide_empty' => false,
                'number' => 8,
            ));

            if (!empty($universities)) :
                foreach ($universities as $university) :
                    ?>
                    <a href="<?php echo get_term_link($university); ?>" class="university-button">
                        <?php echo strtoupper($university->name); ?>
                    </a>
                <?php endforeach;
            endif;
            ?>
        </div>
    </div>
</div>

<?php get_footer(); ?>
