# Installation Guide - Learning Opportunities WordPress Theme

## Quick Start

Follow these steps to install and configure the Learning Opportunities theme on your WordPress website.

## Step 1: Prepare the Theme Package

1. Download the entire `learning-opportunities-theme` folder
2. Create a ZIP file of the folder:
   - On Windows: Right-click the folder > Send to > Compressed (zipped) folder
   - On Mac: Right-click the folder > Compress
   - On Linux: `zip -r learning-opportunities-theme.zip learning-opportunities-theme/`

## Step 2: Install WordPress

If you don't have WordPress installed yet:

1. Download WordPress from wordpress.org
2. Upload to your web server
3. Create a MySQL database
4. Run the WordPress installation wizard
5. Complete the basic setup

## Step 3: Install the Theme

### Method 1: WordPress Admin (Recommended)

1. Log in to your WordPress admin panel
2. Go to **Appearance > Themes**
3. Click **Add New**
4. Click **Upload Theme**
5. Click **Choose File** and select your `learning-opportunities-theme.zip`
6. Click **Install Now**
7. After installation, click **Activate**

### Method 2: FTP Upload

1. Unzip the `learning-opportunities-theme.zip` file
2. Connect to your server via FTP
3. Navigate to `/wp-content/themes/`
4. Upload the `learning-opportunities-theme` folder
5. Go to WordPress Admin > Appearance > Themes
6. Find "Learning Opportunities" and click **Activate**

## Step 4: Configure the Theme

### 4.1 Create Menu Locations

1. Go to **Appearance > Menus**
2. Create a new menu called "Primary Menu"
3. Add menu items:
   - Home (link to your homepage)
   - Wizard (custom link - use # for now)
   - Learning Opportunities (link to /courses/)
4. Under "Menu Settings", check **Primary Menu**
5. Click **Save Menu**

6. Create another menu called "Footer Menu"
7. Add the same items
8. Check **Footer Menu** under Menu Settings
9. Click **Save Menu**

### 4.2 Add Taxonomies (Categories)

#### Add Universities:
1. Go to **Courses > Universities**
2. Add universities, for example:
   - Sorbonne University
   - Heidelberg University
   - University of Warsaw
   - Charles University
   - University of Copenhagen
   - University of Geneva
   - University of Milan
   - Paris Panthéon-Assas University

#### Add Areas of Interest:
1. Go to **Courses > Areas of Interest**
2. Add areas like:
   - Science
   - Humanities
   - Social Sciences
   - Engineering
   - Medicine
   - Arts

#### Add Flagships:
1. Go to **Courses > Flagships**
2. Add flagship programs

#### Add Learning Pathways:
1. Go to **Courses > Learning Pathways**
2. Add pathways like:
   - Multilingualism
   - European Citizenship
   - Digital Skills

#### Add Course Formats:
1. Go to **Courses > Course Formats**
2. Add formats

#### Add Target Groups:
1. Go to **Courses > Target Groups**
2. Add groups

#### Add Languages:
1. Go to **Courses > Languages**
2. Add languages like:
   - EN (English)
   - FR (French)
   - DE (German)
   - PL (Polish)
   - IT (Italian)

### 4.3 Add Your First Course

1. Go to **Courses > Add New**
2. Enter a course title (e.g., "Open Science MOOC")
3. Add course description in the content editor
4. Scroll down to **Course Details** box:
   - ECTS Credits: 15
   - Status: Open (or Closed)
   - Start Date: Select a date
   - Registration Deadline: Select a date
   - Delivery Mode: Online, Hybrid, or Onsite
5. On the right sidebar:
   - Select a University
   - Select Area of Interest
   - Select Learning Pathway
   - Select Languages
   - Select Course Format
   - Select Target Group
6. Click **Publish**

### 4.4 Add More Courses

Repeat the above process to add more courses. Add at least 12 courses to see the full grid layout.

## Step 5: Set Up Homepage (Optional)

1. Go to **Settings > Reading**
2. Choose what displays on your homepage:
   - **Latest posts** (default) - Will show regular blog posts
   - **Static page** - Create a custom homepage
3. Click **Save Changes**

## Step 6: Permalink Settings

1. Go to **Settings > Permalinks**
2. Select **Post name** (recommended)
3. Click **Save Changes**
4. This will make your URLs cleaner: `/courses/course-name/` instead of `?p=123`

## Step 7: Test the Theme

1. Visit your site's homepage
2. Navigate to Learning Opportunities page (or /courses/)
3. Test the filters:
   - Search for courses
   - Filter by university
   - Adjust ECTS slider
   - Try different combinations
4. Click on a course to view details
5. Test on mobile devices

## Troubleshooting

### Courses page shows 404 error
- Go to **Settings > Permalinks** and click **Save Changes** to flush rewrite rules

### Filters not working
- Make sure jQuery is loaded (it comes with WordPress by default)
- Check browser console for JavaScript errors
- Clear browser cache

### Styling looks broken
- Clear browser cache
- Check that the theme is properly activated
- Verify CSS files exist in `/wp-content/themes/learning-opportunities-theme/assets/css/`

### AJAX filtering not working
- Ensure WordPress AJAX is enabled
- Check browser console for errors
- Verify nonce is being generated correctly

## Additional Configuration

### Custom Logo
1. Go to **Appearance > Customize > Site Identity**
2. Upload your logo

### Background Image for Hero Section
1. Edit `assets/css/main.css`
2. Find `.hero-section` class
3. Replace the background URL with your image

### University Logos in Footer
1. Edit `footer.php`
2. Replace `.footer-logo` divs with actual `<img>` tags
3. Upload your logos to Media Library and use those URLs

## Support

If you encounter any issues:

1. Check this installation guide
2. Review the README.md file
3. Check WordPress.org support forums
4. Verify PHP and WordPress versions meet requirements

## Requirements Checklist

- [ ] WordPress 5.0 or higher
- [ ] PHP 7.4 or higher
- [ ] MySQL 5.6 or higher
- [ ] Modern web browser
- [ ] FTP access (optional)

## Next Steps

After installation:

1. Add all your courses
2. Customize colors if needed
3. Add university logos
4. Set up additional pages (About, Contact, etc.)
5. Install essential plugins (SEO, Security, Backup)
6. Test thoroughly before going live

## Going Live

Before launching:

- [ ] Add all course content
- [ ] Test all filters and search
- [ ] Test on multiple browsers
- [ ] Test on mobile devices
- [ ] Set up backups
- [ ] Install security plugins
- [ ] Configure SEO settings
- [ ] Test all links
- [ ] Proofread all content

Congratulations! Your Learning Opportunities website is ready.
