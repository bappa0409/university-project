jQuery(document).ready(function($) {
    let currentPage = 1;
    let maxPages = 1;

    const ectsMinSlider = $('#ects-min');
    const ectsMaxSlider = $('#ects-max');
    const ectsMinValue = $('#ects-min-value');
    const ectsMaxValue = $('#ects-max-value');

    function updateEctsValues() {
        let minVal = parseInt(ectsMinSlider.val());
        let maxVal = parseInt(ectsMaxSlider.val());

        if (minVal > maxVal) {
            const temp = minVal;
            minVal = maxVal;
            maxVal = temp;
            ectsMinSlider.val(minVal);
            ectsMaxSlider.val(maxVal);
        }

        ectsMinValue.text(minVal);
        ectsMaxValue.text(maxVal);
    }

    ectsMinSlider.on('input', updateEctsValues);
    ectsMaxSlider.on('input', updateEctsValues);

    function updateActiveFilters() {
        const activeFiltersContainer = $('#active-filters');
        activeFiltersContainer.empty();

        const search = $('#course-search').val();
        if (search) {
            activeFiltersContainer.append(createFilterTag('Search: ' + search, 'search'));
        }

        const university = $('#filter-university option:selected').text();
        if ($('#filter-university').val()) {
            activeFiltersContainer.append(createFilterTag('University: ' + university, 'university'));
        }

        const area = $('#filter-area option:selected').text();
        if ($('#filter-area').val()) {
            activeFiltersContainer.append(createFilterTag('Area: ' + area, 'area'));
        }

        const flagship = $('#filter-flagship option:selected').text();
        if ($('#filter-flagship').val()) {
            activeFiltersContainer.append(createFilterTag('Flagship: ' + flagship, 'flagship'));
        }

        const pathway = $('#filter-pathway option:selected').text();
        if ($('#filter-pathway').val()) {
            activeFiltersContainer.append(createFilterTag('Pathway: ' + pathway, 'pathway'));
        }

        const format = $('#filter-format option:selected').text();
        if ($('#filter-format').val()) {
            activeFiltersContainer.append(createFilterTag('Format: ' + format, 'format'));
        }

        const target = $('#filter-target option:selected').text();
        if ($('#filter-target').val()) {
            activeFiltersContainer.append(createFilterTag('Target: ' + target, 'target'));
        }

        const language = $('#filter-language option:selected').text();
        if ($('#filter-language').val()) {
            activeFiltersContainer.append(createFilterTag('Language: ' + language, 'language'));
        }

        const minEcts = ectsMinSlider.val();
        const maxEcts = ectsMaxSlider.val();
        if (minEcts != 0 || maxEcts != 30) {
            activeFiltersContainer.append(createFilterTag('ECTS: ' + minEcts + '-' + maxEcts, 'ects'));
        }
    }

    function createFilterTag(text, type) {
        const tag = $('<span class="filter-tag">' + text + ' <button data-filter="' + type + '">&times;</button></span>');
        tag.find('button').on('click', function() {
            removeFilter($(this).data('filter'));
        });
        return tag;
    }

    function removeFilter(type) {
        switch(type) {
            case 'search':
                $('#course-search').val('');
                break;
            case 'university':
                $('#filter-university').val('');
                break;
            case 'area':
                $('#filter-area').val('');
                break;
            case 'flagship':
                $('#filter-flagship').val('');
                break;
            case 'pathway':
                $('#filter-pathway').val('');
                break;
            case 'format':
                $('#filter-format').val('');
                break;
            case 'target':
                $('#filter-target').val('');
                break;
            case 'language':
                $('#filter-language').val('');
                break;
            case 'ects':
                ectsMinSlider.val(0);
                ectsMaxSlider.val(30);
                updateEctsValues();
                break;
        }
        filterCourses();
    }

    function filterCourses(page = 1) {
        currentPage = page;

        const formData = {
            action: 'filter_courses',
            nonce: loAjax.nonce,
            search: $('#course-search').val(),
            university: $('#filter-university').val(),
            area_of_interest: $('#filter-area').val(),
            flagship: $('#filter-flagship').val(),
            learning_pathway: $('#filter-pathway').val(),
            course_format: $('#filter-format').val(),
            target_group: $('#filter-target').val(),
            language: $('#filter-language').val(),
            ects_min: ectsMinSlider.val(),
            ects_max: ectsMaxSlider.val(),
            date_from: $('#filter-date-from').val(),
            date_to: $('#filter-date-to').val(),
            page: page
        };

        $.ajax({
            url: loAjax.ajax_url,
            type: 'POST',
            data: formData,
            beforeSend: function() {
                $('#courses-grid').css('opacity', '0.5');
            },
            success: function(response) {
                if (response.success) {
                    $('#courses-grid').html(response.data.html);
                    $('#course-count').text(response.data.found_posts);
                    maxPages = response.data.max_pages;
                    updateActiveFilters();
                    updatePagination();
                }
            },
            complete: function() {
                $('#courses-grid').css('opacity', '1');
            }
        });
    }

    function updatePagination() {
        $('.page-prev').prop('disabled', currentPage === 1);
        $('.page-next').prop('disabled', currentPage === maxPages);
        $('.page-info').text(currentPage + ' of ' + maxPages);
    }

    $('#search-btn').on('click', function(e) {
        e.preventDefault();
        filterCourses(1);
    });

    $('#clear-btn').on('click', function(e) {
        e.preventDefault();
        $('#course-search').val('');
        $('#filter-university').val('');
        $('#filter-area').val('');
        $('#filter-flagship').val('');
        $('#filter-pathway').val('');
        $('#filter-format').val('');
        $('#filter-target').val('');
        $('#filter-language').val('');
        $('#filter-date-from').val('');
        $('#filter-date-to').val('');
        $('#filter-app-from').val('');
        $('#filter-app-to').val('');
        ectsMinSlider.val(0);
        ectsMaxSlider.val(30);
        updateEctsValues();
        filterCourses(1);
    });

    $('#course-search').on('keyup', function(e) {
        if (e.key === 'Enter') {
            filterCourses(1);
        }
    });

    $('.clear-search').on('click', function() {
        $('#course-search').val('');
        filterCourses(1);
    });

    $('select[id^="filter-"]').on('change', function() {
        filterCourses(1);
    });

    $('.page-prev').on('click', function() {
        if (currentPage > 1) {
            filterCourses(currentPage - 1);
            $('html, body').animate({
                scrollTop: $('.courses-grid').offset().top - 100
            }, 500);
        }
    });

    $('.page-next').on('click', function() {
        if (currentPage < maxPages) {
            filterCourses(currentPage + 1);
            $('html, body').animate({
                scrollTop: $('.courses-grid').offset().top - 100
            }, 500);
        }
    });

    updateEctsValues();
});
